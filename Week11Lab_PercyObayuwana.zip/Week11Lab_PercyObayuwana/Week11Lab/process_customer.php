<?php
require_once('./dao/customerDao.php');
if(isset($_GET['action'])){
    
    
    if($_GET['action'] == "delete"){
        if(isset($_GET['emailAddress'])){
            $customerDao = new customerDao();
            $success = $customerDao->deleteCustomer($_GET['emailAddress']);
            echo $success;
            if($success){
                header('Location:contact.php?deleted=true');
            } else {
                header('Location:contact.php?deleted=false');
            }
        }
    }
}
?>