<?php

	include ('./header.php');
	require_once('./dao/customerDao.php');
	
	$customerDao = new customerDao;
	$customers=$customerDao->getCustomers();
	
	if ($customers){
		echo '<h3>'.'<span style=\'color:green\'>'.'Congratulations! You have sucessfully signed up!'.'</span>'.'</h3>';
		echo '<table width="100%" height="100%" border="5">';
		echo '<tr><th>customerName</th> <th>phoneNumber</th> <th>emailAddress</th> <th>referral</th></tr>';
           // $ID = $customerDao->getID();               
          //  $counter=0;
			foreach($customers as $customer){
				echo '<tr>';
               //echo '<td><a href=\'edit_customer.php?customerName='. $customer->getCustomerName() . '\'>' . $customer->getCustomerName() . '</a></td>';
				echo '<td>' . $customer->getCustomerName() . '</td>';
                echo '<td>' . $customer->getPhoneNumber() . '</td>';
                echo '<td><a href=\'edit_customer.php?emailAddress='. $customer->getEmailAddress() . '\'>' . $customer->getEmailAddress() . '</a></td>';
				//echo '<td>' . $customer->getEmailAddress() . '</td>';
                echo '<td>' . $customer->getReferrer() . '</td>';
                echo '</tr>';
              //  $counter++;
            }
            echo '</table>';
	}
	else{
		echo '<h3>'.'No Existing Mailing Information'.'</h3>';
	}
	
	?>
	
	<?php 
		include './footer.php' 
	?>