<?php
   class customer{
       private $customerName;
       private $phoneNumber;
       private $emailAddress;
       private $referrer;
       
       function __construct($customerName,$phoneNumber,$emailAddress,$referrer){
		$this->setCustomerName($customerName);
		$this->setPhoneNumber($phoneNumber);
		$this->setEmailAddress($emailAddress);
		$this->setReferrer($referrer);
       }
       
       function getCustomerName(){
        return $this->customerName;
       }
       
       function setCustomerName($customerName){
        $this->customerName = $customerName;
       }
    
       function getPhoneNumber(){
        return $this->phoneNumber;
       }
       
       function setPhoneNumber($phoneNumber){
        $this->phoneNumber = $phoneNumber;
       }
     
       function getEmailAddress(){
        return $this->emailAddress;
       }
    
       function  setEmailAddress($emailAddress){
        $this->emailAddress = $emailAddress;
       }
       
       function getReferrer(){
        return $this->referrer;
       }
    
       function setReferrer($referrer){
        $this->referrer = $referrer;
       }
   }
?>