<footer>
          <p>&copy;
		  
		  <?php echo date('Y'); 
		  ?> 
		  
		  CST8285. All Rights Reserved.</p>
 </footer>
 
 </div><!-- End Wrapper -->
    </body>
</html>